SKY RUNNER 3D — starter project

Run locally:
1. Extract this ZIP.
2. Open a terminal in this folder.
3. Run: python -m http.server 8000
4. Open http://localhost:8000 in a modern browser.

Note: the game loads Three.js from jsDelivr, so internet access is required.
For free web publishing, you can upload index.html to a GitHub repository and enable GitHub Pages, or use another free static host. Test the published link on a phone.

This is a playable 3D prototype with procedural graphics, lane movement, jumping, sliding, coins, obstacles, score, pause, and touch buttons. It is not a pixel-perfect recreation of the concept image; custom character/environment art and more polishing would be needed for that level of visual fidelity.
